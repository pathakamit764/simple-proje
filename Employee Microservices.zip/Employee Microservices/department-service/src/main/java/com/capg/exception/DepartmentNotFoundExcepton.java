package com.capg.exception;

public class DepartmentNotFoundExcepton extends Exception {

	public DepartmentNotFoundExcepton() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DepartmentNotFoundExcepton(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
