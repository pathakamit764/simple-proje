package com.capg.exception;

public class LocationNotFoundExcepton extends Exception {

	public LocationNotFoundExcepton() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LocationNotFoundExcepton(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
