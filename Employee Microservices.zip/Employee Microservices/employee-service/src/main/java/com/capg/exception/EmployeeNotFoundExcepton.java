package com.capg.exception;

public class EmployeeNotFoundExcepton extends Exception {

	public EmployeeNotFoundExcepton() {
		super();
		// TODO Auto-generated constructor stub
	}

	public EmployeeNotFoundExcepton(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
